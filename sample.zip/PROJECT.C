/*
 *	PROJECT.C - Home Monitoring System v.1.0

 *  CES 520 - Sonoma State University
 *  ZWorld Rabbit RCM3000 Development Kit
 *  Dynamic C Special Edition Version 7.32TSE
 *  Built 12-05-06: D.Bozarth
 *
*/

#memmap xmem

/* Note: Custom LIB.DIR must be pointed to using Options -> Compiler -> User Defined Library File */
#use "i2c_devices.lib"
#use "onewire.lib"
#use "LED.LIB"
#use "RELAY.LIB"
#use "ALARM.LIB"
#use "WEB.LIB"

#define WELCOME                     "Home Monitoring System v1.0 Dec 2006 (Sonoma State University)"
#define WRITE_TIME           1   // Number of milliseconds to wait between EEPROM write operations 
#define EEPROM_ADDRESS    0xA2   // I2C device address of EEPROM chip
#define EE_LO_OFFSET        32
#define EE_HI_OFFSET        40

#define DEFAULT_TEMP      26.0   // Default desired temperature
#define TEMP_VARIATION     1.0   // Number of degrees C the temp is allowed to vary from desired
#define HEAT_FAN_DELAY      10   // Number of seconds the fan remains ON after heat relay is OFF
#define COOL              Rly0
#define HEAT              Rly1
#define FAN               Rly2
#define ALARM             Rly3
#define COOL_LED          Led0
#define HEAT_LED          Led1
#define ALARM_LED         Led2

#define BREAK                       "<BR>"
#define TEMP_TAG                    "Temperature = "
#define C_TAG                       " C"
#define ALM_TAG                     "Alarm status = "
#define ALM_STA_ON                  "* ON *"
#define ALM_STA_OFF                 " OFF  "
#define ALM_TAG_LEN         15
#define ALM_STA_LEN          6
#define BR_LEN               4   // Length of standard line break
#define LFT_LEN            131   // Length of first part of my_response
#define RGT_LEN             19   // Length of last part of my_response
#define TIME_LEN            19   // Length of time string
#define TEMP_TAG_LEN        14   // Length of temperature base string
#define C_TAG_LEN            2   // Length of deg-C tag
#define TEMP_DECIMALS        6   // Number of decimal places to display for temperature
#define ALM_STA_DFLT                ALM_STA_OFF
#define TEMP_LEN                    TEMP_DECIMALS + 3
#define TEMP_STR_LEN                TEMP_TAG_LEN + TEMP_LEN + C_TAG_LEN
#define ALARM_LEN                   ALM_TAG_LEN + ALM_STA_LEN
#define HTML_LEN                    TIME_LEN + BR_LEN + TEMP_STR_LEN + BR_LEN + ALARM_LEN
#define HTTP_LEN                    LFT_LEN + HTML_LEN + RGT_LEN

#define NIL                  0
#define SPC_CHR            ' '
#define SPC_STR            " "

// my_response is the "page" that is sent back to any query.
const char my_response_left[] =
	"HTTP/1.0 200 OK\r\n" \
	"Content-Type: text/html\r\n\r\n" \
	"<HTML>" \
	"<HEAD><meta http-equiv='refresh' content='5'><TITLE>test</TITLE></HEAD>" \
	"<BODY><H1>";

const char my_response_right[] = 
   "</H1></BODY>" \
	"</HTML>";
	
static char  my_response[HTTP_LEN + 1]; // built by pgm, displayed on web page
static long  current_time;              // from on-board RTC
static float current_temp;              // determined by sensor
static float desired_temp;              // input from web page 

////////////////////////////////////////////////////////////////////////////
/* FUNCTION DECLARATIONS */
////////////////////////////////////////////////////////////////////////////
void testLeds();
void testRelaysRun();

void ip_eeprom();
int store_ip(char offset, char *ip_in);
int fetch_ip(char offset, char *ip_out);

int hilo_eeprom(char adx, char offset_lo, char offset_hi,
                float des_tmp, char *s_des_tmp,
                float dif_tmp, char *s_dif_tmp
               );
               
void build_response(char *s_cur_tme, char *s_break,
                    char *s_cur_tmp, char *s_des_tmp,
                    char *s_tmp_tag, char *s_c_tag,
                    char *s_alm_sta, char *s_alm_tag,
                    char *response_lft,
                    char *response_rgt,
                    char *response_msg, size_t len_msg                
                   );

void my_init   (MyState* my_state);
void my_handler(MyState* state);
unsigned long get_time(struct tm *rtc, char *s_cur_tme);
char *build_time(unsigned long);
void int_field(int i_in, char *field, char *tmp_field, char pad, int alloc);

////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
/*
 *		main() initializes DCRTCP by calling sock_init and the
 *		MyState by my_init.  It then calls my_handler repeatitively
 *		the the MyState.  If you wanted to extend this to have 
 *		multiple connections, add more MyStates with their own calls
 *		to the my_handler.
 *
 */

main()
{
	auto int sw0, sw1, sw2, rst, alm, heat, cool, err, i;
   auto char s_current_time[TIME_LEN    + 1];
   auto char s_buffer[16];
   auto unsigned long tme;	   // used for date->seconds conversion
   auto struct tm stu_tme;    // time from RTC
   
   auto char s_current_temp[TEMP_LEN    + 1];
   auto char s_desired_temp[TEMP_LEN    + 1];
   auto char s_delta_temp  [TEMP_LEN    + 1];
   auto char s_alarm_status[ALM_STA_LEN + 1];
  
	MyState my_state;

	heat = cool = OFF;
   desired_temp = DEFAULT_TEMP;
   
   printf("\n%s\n\n", WELCOME);
   
   sprintf(s_buffer, "%f", DEFAULT_TEMP);
   strncpy(s_desired_temp, s_buffer,     TEMP_LEN    + 1);
   sprintf(s_buffer, "%f", TEMP_VARIATION);
   strncpy(s_delta_temp,   s_buffer,     TEMP_LEN    + 1);	
   strncpy(s_alarm_status, ALM_STA_DFLT, ALM_STA_LEN + 1);
	
   initPortLed();
	initPortAlarm();
	initPortRelay();
	
   ip_eeprom();
   err = hilo_eeprom(EEPROM_ADDRESS, EE_LO_OFFSET, EE_HI_OFFSET,
                     desired_temp,   s_desired_temp,
                     TEMP_VARIATION, s_delta_temp
                    );
   if (err) {
      printf("EEPROM error - exiting.");
      exit(err);
   }
                    
   OW_Reset();                // initialize One-Wire bus.                
	sock_init();

	//		The reserve port function enables SYN queuing.  This
	//		allows connections to be held pending if there is no
	//		socket to handle the port.
	tcp_reserveport(MY_PORT); 
	my_init(&my_state);

   tme = get_time(&stu_tme, s_current_time);
       	
	costate {   // Initial temperature reading	
      waitfor(IntervalSec(2));
      temperatureConvert();
      waitfor (DelayMs(850));
      err = temperatureRead(&current_temp);
      
      if (!err) {
         printf("Temperature = %f C\n\n", current_temp);
      } else {
         printf("Temperature sensor failed to respond\n\n");  
      }
         
      sprintf(s_current_temp, "%f", current_temp);     
      sprintf(s_desired_temp, "%f", desired_temp);   
	}

   build_response(s_current_time, BREAK,
                  s_current_temp, s_desired_temp,
                  TEMP_TAG, C_TAG,
                  s_alarm_status, ALM_TAG,
                  my_response_left, 
                  my_response_right, 
                  my_response, HTTP_LEN 
                 );                 
   //printf("[%s]\n\n", my_response);

   // main loop
	for(;;) {

	   costate {
         tme = get_time(&stu_tme, s_current_time);    
	   }
	   
	   costate {   // Operate the alarm system.     
         // Aquire the state of the Reset Alarm switch.
			sw0 = 0x000f ; sw1 = 0x00f0 ; sw2 = 0x0f00;
         while ((sw0 != sw1) || (sw0 != sw2) || (sw1 != sw2)) {
         	sw0 = ReadResetAlarm();
            waitfor(DelayMs(50));
         	sw1 = ReadResetAlarm();
            waitfor(DelayMs(50));
         	sw2 = ReadResetAlarm();
         }
			rst = sw0;

			// Don't worry about the meanings of ON & OFF - everything works.
			
			// Turn off the Alarm Relay if the Reset Alarm switch is closed.
			if (rst == ON) {
			   ALARM(OFF);
			   //strncpy(s_alarm_status, ALM_STA_OFF, ALM_STA_LEN + 1);
			}				

		   // Acquire the state of the Alarm 0 switch.
			sw0 = 0x000f ; sw1 = 0x00f0 ; sw2 = 0x0f00;
         while ((sw0 != sw1) || (sw0 != sw2) || (sw1 != sw2)) {
         	sw0 = ReadAlarm(0);
            waitfor(DelayMs(50));
         	sw1 = ReadAlarm(0);
            waitfor(DelayMs(50));
         	sw2 = ReadAlarm(0);
         }
			alm = sw2;

			// Turn on the Alarm Relay and LED if both conditions are true:
			//	1. the Alarm 0 switch is closed, and
			//	2. the Reset Alarm switch is open.
			if (alm == ON && rst == OFF) {
				ALARM(ON);
				ALARM_LED(OFF);
				strncpy(s_alarm_status, ALM_STA_ON,  ALM_STA_LEN + 1);
         }

			// Turn off the Alarm Relay and LED if both conditions are true:
			//	1. the Alarm 0 switch is open, and
			//	2. the Reset Alarm switch has been closed.
         if (alm == OFF && rst == ON) {
            ALARM(OFF);
            ALARM_LED(ON);
            strncpy(s_alarm_status, ALM_STA_OFF, ALM_STA_LEN + 1);
         }        
		}

      costate {   // Read temperature sensor and operate climate controls.
         waitfor(IntervalSec(2));
         desired_temp = DEFAULT_TEMP;
         temperatureConvert();
         waitfor (DelayMs(850));
         err = temperatureRead(&current_temp);
         
         if (!err) {
            printf("Temperature = %f C\n\n", current_temp);
         } else {
            printf("Temperature sensor failed to respond\n\n");  
         }

         if (desired_temp + TEMP_VARIATION < current_temp) {
            cool = ON;
         	COOL(ON);
         	FAN(ON);
         	COOL_LED(OFF);
         } else {
            if (cool == ON) {
               cool = OFF;
         	   COOL(OFF);
         	   COOL_LED(ON);
         	}         	
         }         

         if (current_temp < desired_temp - TEMP_VARIATION) {
            heat = ON;
            HEAT(ON);
            FAN(ON);
            HEAT_LED(OFF);
         } else {
            if (heat == ON) {
               heat = OFF;
               HEAT(OFF);
               HEAT_LED(ON);          
               waitfor(DelaySec(HEAT_FAN_DELAY));
            }
            if (cool == OFF) FAN(OFF);
         }

         sprintf(s_current_temp, "%f", current_temp);
         sprintf(s_desired_temp, "%f", desired_temp);            
      }		

		costate {   // Update web display.
		   waitfor(IntervalMs(1000));		   
         build_response(s_current_time, BREAK,
                        s_current_temp, s_desired_temp,
                        TEMP_TAG, C_TAG,
                        s_alarm_status, ALM_TAG,
                        my_response_left, 
                        my_response_right, 
                        my_response, HTTP_LEN 
                       );
      }
      
      my_handler(&my_state);
	}

}

//////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////
/* FUNCTION DEFINITIONS */
///////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
void build_response(char *s_cur_tme, char *s_break,
                    char *s_cur_tmp, char *s_des_tmp,
                    char *s_tmp_tag, char *s_c_tag,
                    char *s_alm_sta, char *s_alm_tag,
                    char *response_lft,
                    char *response_rgt,                    
                    char *response,     size_t len_msg,
                   )                   
{
   auto int  i;

   for (i = 0; i <= len_msg; ++i) {
	   response[i] = NIL;
   }

   strncpy(response, response_lft, strlen(response_lft) + 1);
   strncat(response, s_cur_tme,    strlen(s_cur_tme)    + 1);
   strncat(response, s_break,      strlen(s_break)      + 1);
   strncat(response, s_tmp_tag,    strlen(s_tmp_tag)    + 1);
   strncat(response, s_cur_tmp,    strlen(s_cur_tmp)    + 1);
   strncat(response, s_c_tag,      strlen(s_c_tag)      + 1);
   strncat(response, s_break,      strlen(s_break)      + 1);
   strncat(response, s_alm_tag,    strlen(s_alm_tag)    + 1);
   strncat(response, s_alm_sta,    strlen(s_alm_sta)    + 1);   
   strncat(response, response_rgt, strlen(response_rgt) + 1);
   
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
unsigned long get_time(struct tm *rtc, char *s_cur_tme)
{
   auto unsigned long t0;	       // used for date->seconds conversion

   tm_rd(rtc);						    // get time in struct tm
   t0 = mktime(rtc);				    // convert struct tm into seconds since 1980
   strncpy(s_cur_tme,   build_time(t0), TIME_LEN + 1);
   		
 	return t0;
   
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
void ip_eeprom()
{
   auto int err;
   auto char read_string[16];
   
   printf("Writing IP Address %s to EEPROM offset %d ...\n", MY_IP_ADDRESS, MY_IP_OFFSET);
   err = store_ip(MY_IP_OFFSET, MY_IP_ADDRESS);

   if (!err) {
		printf("Reading address back...\n");
      err = fetch_ip(MY_IP_OFFSET, read_string);

		if (!err) {
			printf("Read back %s\n", read_string);
      } else {
         printf("Read error.\n");
      }
   } else {
      printf("Write error.\n");
   }
   	
   //printf("\n%s\n", MY_IP_ADDRESS);
   printf("\n");

}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// 
// Returns: 0 if success
//          1 if write error
//          2 if read error
//
int hilo_eeprom(char adx, char offset_lo, char offset_hi,
                float des_tmp, char *s_des_tmp,
                float dif_tmp, char *s_dif_tmp
               )
{
   auto int rtn;
   auto float lo, hi;
   auto char s_lo[16], s_hi[16];
   auto char read_string[16];

   lo = des_tmp - dif_tmp;
   hi = des_tmp + dif_tmp;
   
   sprintf(s_lo, "%f", lo);
   sprintf(s_hi, "%f", hi);
   
   printf("Writing Low  Temp Threshold %s to EEPROM offset %d ...\n", s_lo, offset_lo);
   rtn = I2CWrite(adx, offset_lo, s_lo, 8);
   if (rtn != 0) {
      printf("Write error.\n");
      return 1;
   }

   printf("Writing High Temp Threshold %s to EEPROM offset %d ...\n", s_hi, offset_hi);
   rtn = I2CWrite(adx, offset_hi, s_hi, 8);
   if (rtn != 0) {
      printf("Write error.\n");
      return 1;
   }
   
   printf("Reading Low  Temp Threshold from EEPROM offset %d ...\n", offset_lo);
   rtn = I2CRead(adx, offset_lo, read_string, 8);
   if (rtn == 0) {
      strncpy(s_lo, read_string, 8);
      s_lo[8] = NIL;   
      printf("Read back %s\n", s_lo);
   } else {
      printf("Read error.\n");     
      return 2;
   }

   printf("Reading High Temp Threshold from EEPROM offset %d ...\n", offset_hi);
   rtn = I2CRead(adx, offset_hi, read_string, 8);
   if (rtn == 0) {
      strncpy(s_hi, read_string, 8);
      s_hi[8] = NIL;   
      printf("Read back %s\n", s_hi);
   } else {
      printf("Read error.\n");     
      return 2;
   }

   printf("\n");
   return 0;
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
/* pre:  ip_in represents an IP address null-terminated: min 8 + null padded to 16; max 15 + null.
 * post: The IP address has been stored as a string of char in the EEPROM,
 *        starting at offset and occupying 15 bytes (null padded up to 15).
 */
int store_ip(char offset, char *ip_in)
{
	auto int rtn;
   auto char first_string[9];
   auto char second_string[8];

	i2c_init();

   strncpy(first_string, ip_in, 8);
   first_string[8] = 0;
   strncpy(second_string, ip_in + 8, 8);
   second_string[strlen(ip_in) - 7] = 0;

	rtn = I2CWrite(EEPROM_ADDRESS, offset, first_string, 8);
   if (rtn != 0) return rtn;
  
	rtn = I2CWrite(EEPROM_ADDRESS, offset + 8, second_string, 7);
   return rtn;

}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
/* pre:  An IP address has been stored as a string of char in the EEPROM,
 *        starting at offset and occupying 15 bytes (null padded up to 15).
 *        ip_out has 16 bytes allocated.
 * post: ip_out represents an IP address null-terminated: min 8 + null padded to 16; max 15 + null. 
 */
int fetch_ip(char offset, char *ip_out) {
	auto int rtn;
   auto char first_string[9];
   auto char second_string[8];

	i2c_init();

	rtn = I2CRead(EEPROM_ADDRESS, offset, first_string, 8);
   if (rtn != 0) return rtn;

   first_string[8] = 0;
   strncpy(ip_out, first_string, 9);

	rtn = I2CRead(EEPROM_ADDRESS, offset + 8, second_string, 7);
   second_string[7] = 0;
   strncat(ip_out, second_string, 8);

   return rtn;
}
//////////////////////////////////////////////////////////////////////////	

//////////////////////////////////////////////////////////////////////////
/*
 *		my_init sets the MyState.state to the initial
 *		state so it will be initialized on the first pass 
 *		through the handler.
 *
 */
void my_init(MyState* my_state)
{
	my_state->state=MY_INIT;
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
/*
 *		my_handler is a function that is passed a MyState
 *		structure and manages the connection.  The first time
 *		the function is called on a MyState the MyState->state
 *		should be MY_INIT.  The hander does a passive open on
 *		the socket and waits for a connection.  When a 
 *		connection is established it reads the http request
 *		and header lines waiting for \r\n\r\n.  At this point
 *		the handler sends the my_response and closes the 
 *		connection.  After the connection has been confirmed
 *		closed the MyState.state is set back to MY_INIT.
 *
 *		It is important to notice how sock_mode and sock_dataready
 *		interact in MY_LISTEN, MY_GETREQ and MY_GETHEAD.  Since
 *		the socket mode is TCP_MODE_ASCII in MY_GETREQ and 
 *		MY_GETHEAD, the sock_dataready function will only return
 *		when there is a \r\n terminated string in the buffer or
 *		the buffer has been completely filled.  This allows us
 *		to call sock_gets which would normally block without
 *		worrying that it will actually block.
 *
 *		The second thing to notice is the use of sock_fastwrite
 *		in MY_SENDRSP.  This function only writes as much data
 *		as there is buffer space at the moment it is called.  
 *		This method using the offset moving towards the length
 *		can be used to make sure all of the data is sent.
 *
 */
void my_handler(MyState* state)
{
	auto tcp_Socket* socket;
	auto int bytes_written;

	socket=&state->socket;
	
	/*
	 *		was the connection reset?
	 */
	if(state->state!=MY_INIT && tcp_tick(socket)==0)
		state->state=MY_INIT;
		
	switch(state->state) 
	{
		case MY_INIT:
			/*
			 *		passive open on the socket port:  MY_PORT
			 */
			tcp_listen(socket,MY_PORT,0,0,NULL,0);
			state->state=MY_LISTEN;
			printf("\nInitializing socket\n");
			break;
			
		case MY_LISTEN:
			/*
			 *		wait for a connection
			 */
			if(sock_established(socket)) {
				state->state=MY_GETREQ;
				sock_mode(socket,TCP_MODE_ASCII);
				printf("New Connection\n");
			}
			break;
			
		case MY_GETREQ:
			/*
			 *		process the request line.
			 */
			if(sock_dataready(socket)) {
				sock_gets(socket,state->buffer,256);
				state->state=MY_GETHEAD;
				printf("%s\nHeaders\n",state->buffer);
			}
			break;
			
		case MY_GETHEAD:
			/*
			 *		process any headers
			 */
			if(sock_dataready(socket)) {
				sock_gets(socket,state->buffer,256);
				printf("%s\n",state->buffer);
				
				/*
				 *		When there is an empty line we know that
				 *		the browser is done sending headers.
				 */
				if(state->buffer[0]==0) {
					state->state=MY_SENDRSP;
					sock_mode(socket,TCP_MODE_BINARY);
					state->offset=0;
					state->length=strlen(my_response);
					printf("Sending Response:\n%s\n",my_response);
				}
			}
			break;
			
		case MY_SENDRSP:
			bytes_written=sock_fastwrite(socket,my_response+state->offset,
				state->length-state->offset);
				
			state->offset+=bytes_written;
			
			/*
			 *		if there is an error or we have written out the
			 *		entire my_response.
			 *
			 */
			if(bytes_written<0 ||
				state->offset>=state->length) {
				sock_close(socket);
				state->state=MY_WAITCLOSE;
				printf("Closing Socket\n");
			}
			break;
			
		case MY_WAITCLOSE:
			break;
			
		default:
			/*
			 *		how did we get here?  programming error?
			 */
			state->state=MY_INIT;
			break;
	}
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
char *build_time(unsigned long thetime)
{
	auto struct tm	thetm;
	auto char timestr[TIME_LEN + 1];
	auto char s_month[3], s_day[3], s_year[5], s_hour[3], s_min[3], s_sec[3];
	auto char s_tmp3[3], s_tmp5[5]; // Scratchpad strings
   auto int i;

   for (i = 0 ; i < TIME_LEN + 1 ; ++i) {
	   timestr[i] = NIL;
   }
	
	mktm(&thetm, thetime);
		
	//printf("[[%02d/%02d/%04d %02d:%02d:%02d]]\n\n",
	//		thetm.tm_mon, thetm.tm_mday, 1900+thetm.tm_year,
	//		thetm.tm_hour, thetm.tm_min, thetm.tm_sec);

	int_field((int) thetm.tm_mon, s_month, s_tmp3, '0', 3);
   int_field((int) thetm.tm_mday, s_day, s_tmp3, '0', 3);

   //int_field((int) thetm.tm_year, s_year, s_tmp5, '0', 5); // Doesn't work for year.	     
   itoa((int) thetm.tm_year + 1900, s_year); // We know this is 4 digits.
	s_year[4] = NIL;
	
   int_field((int) thetm.tm_hour, s_hour, s_tmp3, '0', 3);
   int_field((int) thetm.tm_min, s_min, s_tmp3, '0', 3);	
   int_field((int) thetm.tm_sec, s_sec, s_tmp3, '0', 3);	
	
	strncpy(timestr, s_month, 3);	
	strncat(timestr, "/",     2);	
	strncat(timestr, s_day,   3);	
	strncat(timestr, "/",     2);	
	strncat(timestr, s_year,  5);
	strncat(timestr, SPC_STR, 2);	
	strncat(timestr, s_hour,  3);	
	strncat(timestr, ":",     2);	
	strncat(timestr, s_min,   3);	
	strncat(timestr, ":",     2);
	strncat(timestr, s_sec,   3);	
	
	return timestr;

}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
/*
 * Right-justify an integer in a character field of desired length.
 * alloc is desired field length plus one.
 * TESTED OK FOR 2-digit integer ONLY. 11-21-06
 *
*/
void int_field(int i_in, char *field, char *tmp_field, char pad, int alloc) {
   auto int i, j, k;

   for (i = 0 ; i < alloc ; ++i) {
   	field[i] = NIL;
   }
   for (i = 0 ; i < alloc ; ++i) {
   	tmp_field[i] = NIL;
   }   
   itoa((int) i_in, tmp_field);

   for (i = 0 ; i < alloc ; ++i) {
      if (tmp_field[i] == NIL) {
         break;
      }
   }   
	j = alloc - (i + 1);

	for (i = 0 ; i < j ; ++i) {
	   field[i] = pad;
   }

   k = 0;
	for (j = i ; j < alloc ; ++j) {
	   field[j] = tmp_field[k++];
	}

}	
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
/* End of PROJECT.C */
//////////////////////////////////////////////////////////////////////////