/**************************************************************************************
				ONEWIRE.LIB
* Driver for a single channel.
* (See the original file ONEWIRE.LIB for use with 4 channels.)
*
* Mod 09-23-06	D.Bozarth. Use no CD4051.
* Mod 12-03-06 D.Bozarth. Fix temperatureRead() calculation per A.Bloom. New signatures.		
**************************************************************************************/
/*** Beginheader temperatureConvert*/

void temperatureConvert();

/*** endheader */

/**************************************************************************************
 Function: 					temperatureConvert()
 Purpose:
   This function initiates a temperature convert to a single digital thermometer.
   Bi-directional port pin PD3 is used for the 1-wire I/O. 
**************************************************************************************/
void temperatureConvert() {
   WrPortI(PADR, &PADRShadow, (PADRShadow & 0x0fc) | 0x01); 
   if (OW_Reset()) {				// if sensor present 
      OW_Write(0xcc); 
      OW_Write(0x44);
   }
}

/*** Beginheader temperatureRead*/

byte temperatureRead(float *tmpr);

/*** endheader */

/**************************************************************************************
 Function: 					temperatureRead()
 Purpose:
 	This function reads the temperature of the digital thermometer.
   Bi-directional port pin PD3 is used for the 1-wire I/O. 
**************************************************************************************/
byte temperatureRead(float *tmpr) {
   auto byte bt, err;

   WrPortI(PADR, &PADRShadow, (PADRShadow & 0x0fc) | 0x01);
   if(OW_Reset()) {
      OW_Write(0xcc); 
      OW_Write(0xbe);          
      bt = OW_Read(); 
      *tmpr = (bt + 256.0 * OW_Read()) / 16;
      err = 0x00;
   }
   else {
      *tmpr = 0.0;
      err = 0xff;
   }
   return err;
}

// ****************************** 1 Wire assembly routines  ********************************

/*** Beginheader OW_Reset */

int OW_Reset(void);

/*** endheader */
 

// Reset bus and watch for presence pulse 
// Return 1 if present, 0 if not 

int OW_Reset(void) 
{ 
int present; 
present = 0; 

#asm 
									// Set line to output 
	ld a, (PDDDRShadow) 
	set 3, a						// port D3 
	ioi ld (PDDDR), a 
	ld (PDDDRShadow), a 

									// Make output 0 
	ld a, (PDDRShadow) 
	res 3, a						// port D3  
	ioi ld (PDDR), a 
	ld (PDDRShadow), a 


	call OW_Tick				// Sync with TICK_TIMER 
	call OW_Tick				// Wait a full tick 
 

									// Set line to input 
	ld a, (PDDDRShadow) 
	res 3, a 
	ioi ld (PDDDR), a 
	ld (PDDDRShadow), a 

									// Wait about 60 uSec 
	ld b, 60 
	call OW_Delay 

									// Test for pulse 
	ioi ld a, (PDDR) 
	and a, 8						// port D3  
	cp a, 8						// port D3  
	jp z, OW_R30 
	ld hl, 1 
	ld (present), hl 

	OW_R30: 
									// Wait for device to time out 
	call OW_Tick 

#endasm 
	return(present); 
} 

/*** Beginheader OW_Write */

void OW_Write(char data);

/*** endheader */
 
 
void OW_Write(char data) 
{ 
#asm 
	ld h, 8 

	OW_W10: 
	call OW_Input 

									// Wait about 13 uSec 
	ld b, 13 
	call OW_Delay 

	IPSET 3						// Disable OS interrupt
	call OW_Output 
	rr l 
	jr nc, OW_W20 
	call OW_Input 
	OW_W20: 
	ld b, 60 
	call OW_Delay 
	call OW_Input 
	IPSET 0						// Enable OS interrupt

	dec h 
	jr nz, OW_W10 
	#endasm 
} 
 

/*** Beginheader OW_Read */

char OW_Read(void);

/*** endheader */
 
char OW_Read(void) 
{ 
char data; 

#asm 
	ld h, 8 
	OW_R10: 
	IPSET 3						// Disable OS interrupt
	call OW_Output				// Send Master read slot 0 
	call OW_Input 

									// Wait about 11 uSec 
	ld b, 11 
	call OW_Delay 

	ioi ld a, (PDDR) 
	IPSET 0						// Enable OS interrupt
	rra							// 3 extra "rra" for port D3 instead of D0 
	rra 
	rra 
	rra 
	rr c 

	ld b, 60 
	call OW_Delay 
	dec h 
	jr nz, OW_R10 
	ld a, c 
	ld (data), a 
#endasm 
	return (data); 
} 


// 
// uSec Delay, counts b down 
// 
#asm 
	OW_Delay:: 
	nop 
	nop 
	nop 
	nop 
	nop 
	nop 
	djnz OW_Delay 
	ret 
#endasm 


// 
// Make wire Output 
// 
#asm 
	OW_Output:: 
	ld a, (PDDDRShadow) 		// set data direction to output (low)
	set 3, a						// port D3  
	ioi ld (PDDDR), a 
	ld (PDDDRShadow), a 

	ld a, (PDDRShadow)		// set output low. 
	res 3, a						// port D3  
	ioi ld (PDDR), a 
	ld (PDDRShadow), a 

	ret 
#endasm 


// 
// Make wire input 
// 
#asm 
	OW_Input:: 
	ld a, (PDDDRShadow) 		// set data direction to input (high) 
	res 3, a						// port D3  
	ioi ld (PDDDR), a 
	ld (PDDDRShadow), a 
	ret 
#endasm 


// 
// Wait for TICK_TIMER change 
// 
#asm 
	OW_Tick:: 
	ld ix, TICK_TIMER 
	ld a, (ix + 0) 

									// Sync with TICK_TIMER 
	OW_T10: 
	cp (ix + 0) 
	jp z, OW_T10 

	ret 
#endasm

/* End of ONEWIRE.LIB */