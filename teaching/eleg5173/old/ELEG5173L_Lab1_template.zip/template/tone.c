/*
 *  Copyright 2002 by Spectrum Digital Incorporated.
 *  All rights reserved.  Property of Spectrum Digital Incorporated.
 */

/*
 *  ======== tone.c ========
 *
 *  This example uses the AIC23 codec module of the 5510 DSK Board Support
 *  Library to generate a 1KHz sine wave on the audio outputs for 5 seconds.
 *  The sine wave data is pre-calculated in an array called sinetable.  The
 *  codec operates at 48KHz by default.  Since the sine wave table has 48
 *  entries per period, each pass through the inner loop takes 1 millisecond.
 *  5000 passes through the inner loop takes 5 seconds.
 *
 *  Please see the 5510 DSK help file under Software/Examples for more
 *  detailed information.
 */

/*
 *  DSP/BIOS is configured using the DSP/BIOS configuration tool.  Settings
 *  for this example are stored in a configuration file called tone.cdb.  At
 *  compile time, Code Composer will auto-generate DSP/BIOS related files
 *  based on these settings.  A header file called tonecfg.h contains the
 *  results of the autogeneration and must be included for proper operation.
 *  The name of the file is taken from tone.cdb and adding cfg.h.
 */
#include "tonecfg.h"

/*
 *  The 5510 DSK Board Support Library is divided into several modules, each
 *  of which has its own include file.  The file DSK6713.h must be included
 *  in every program that uses the BSL.  This example also includes
 *  DSK6713_aic23.h because it uses the AIC23 codec module.
 */
#include "DSK6713.h"
#include "DSK6713_aic23.h"
#include "DSK6713_led.h"
#include "DSK6713_dip.h"

/* Sampling rate */
#define SAMPLE_RATE 48000
#define FREQ_0 262
#define FREQ_1 294

/* freq = 262 Hz */
#define SINE_TABLE_SIZE_0 (Uint16)SAMPLE_RATE/FREQ_0
/* freq = 294 Hz */
#define SINE_TABLE_SIZE_1 (Uint16)SAMPLE_RATE/FREQ_1

/* there are 4 DIP switches */
#define N_switch 4
/* the duration of each key push is 1 second */
#define DURATION 0.4


/* Codec configuration settings */
DSK6713_AIC23_Config config = {
    0x0017, // 0 DSK6713_AIC23_LEFTINVOL  Left line input channel volume
    0x0017, // 1 DSK6713_AIC23_RIGHTINVOL Right line input channel volume
    0x00d8, // 2 DSK6713_AIC23_LEFTHPVOL  Left channel headphone volume
    0x00d8, // 3 DSK6713_AIC23_RIGHTHPVOL Right channel headphone volume
    0x0011, // 4 DSK6713_AIC23_ANAPATH    Analog audio path control
    0x0000, // 5 DSK6713_AIC23_DIGPATH    Digital audio path control
    0x0000, // 6 DSK6713_AIC23_POWERDOWN  Power down control
    0x0043, // 7 DSK6713_AIC23_DIGIF      Digital audio interface format
    0x0081, // 8 DSK6713_AIC23_SAMPLERATE Sample rate control
    0x0001  // 9 DSK6713_AIC23_DIGACT     Digital interface activation
};

/* Pre-generated sine wave data, 16-bit signed samples */
Uint32 sinetable_0[SINE_TABLE_SIZE_0] = {
    0x0000,0x0463,0x08C5,0x0D25,0x1181,0x15D7,0x1A27,0x1E6F,0x22AE,0x26E2,0x2B0B,0x2F26,0x3334,0x3732,0x3B1F,0x3EFB,0x42C3,0x4678,0x4A17,0x4DA0,0x5112,0x546B,0x57AB,0x5AD1,0x5DDB,0x60C9,0x6399,0x664C,0x68E0,0x6B54,0x6DA8,0x6FDB,0x71ED,0x73DC,0x75A8,0x7751,0x78D6,0x7A36,0x7B72,0x7C88,0x7D79,0x7E44,0x7EE9,0x7F68,0x7FC1,0x7FF3,0x7FFF,0x7FE4,0x7FA2,0x7F3B,0x7EAC,0x7DF8,0x7D1E,0x7C1E,0x7AF9,0x79AE,0x7840,0x76AC,0x74F6,0x731B,0x711F,0x6F00,0x6CC0,0x6A5F,0x67DE,0x653E,0x627F,0x5FA2,0x5CA9,0x5994,0x5664,0x531A,0x4FB7,0x4C3C,0x48AA,0x4502,0x4145,0x3D75,0x3992,0x359E,0x319A,0x2D86,0x2965,0x2538,0x20FF,0x1CBD,0x1872,0x141F,0x0FC6,0x0B69,0x0708,0x02A5,0xFE41,0xF9DE,0xF57D,0xF11F,0xECC5,0xE871,0xE424,0xDFE0,0xDBA5,0xD775,0xD351,0xCF3B,0xCB34,0xC73C,0xC356,0xBF81,0xBBC1,0xB814,0xB47E,0xB0FE,0xAD96,0xAA46,0xA711,0xA3F6,0xA0F7,0x9E15,0x9B50,0x98A9,0x9622,0x93BA,0x9173,0x8F4D,0x8D4A,0x8B68,0x89AA,0x8810,0x8699,0x8547,0x841A,0x8313,0x8231,0x8175,0x80DF,0x806F,0x8026,0x8003,0x8006,0x8031,0x8081,0x80F8,0x8196,0x8259,0x8342,0x8451,0x8585,0x86DE,0x885B,0x89FD,0x8BC1,0x8DA9,0x8FB4,0x91E0,0x942D,0x969B,0x9928,0x9BD5,0x9E9F,0xA187,0xA48C,0xA7AC,0xAAE6,0xAE3A,0xB1A7,0xB52B,0xB8C6,0xBC76,0xC03B,0xC413,0xC7FD,0xCBF7,0xD002,0xD41B,0xD841,0xDC73,0xE0AF,0xE4F6,0xE944,0xED99,0xF1F4,0xF653,0xFAB4,
};


Uint32 sinetable_1[SINE_TABLE_SIZE_1] = {
	0x0000,0x04EC,0x09D7,0x0EBE,0x13A0,0x187A,0x1D4B,0x2211,0x26C9,0x2B73,0x300D,0x3495,0x3908,0x3D66,0x41AC,0x45DA,0x49ED,0x4DE5,0x51BE,0x5579,0x5913,0x5C8C,0x5FE1,0x6312,0x661E,0x6902,0x6BBF,0x6E54,0x70BE,0x72FD,0x7511,0x76F9,0x78B3,0x7A40,0x7B9F,0x7CCE,0x7DCE,0x7E9F,0x7F3F,0x7FAF,0x7FEF,0x7FFF,0x7FDE,0x7F8C,0x7F0A,0x7E58,0x7D76,0x7C64,0x7B23,0x79B4,0x7816,0x764B,0x7453,0x722F,0x6FE0,0x6D66,0x6AC3,0x67F7,0x6504,0x61EA,0x5EAC,0x5B49,0x57C4,0x541E,0x5058,0x4C73,0x4871,0x4454,0x401D,0x3BCE,0x3768,0x32ED,0x2E5F,0x29BF,0x250F,0x2051,0x1B87,0x16B3,0x11D6,0x0CF2,0x0809,0x031D,0xFE30,0xF944,0xF45A,0xEF75,0xEA96,0xE5BF,0xE0F2,0xDC31,0xD77D,0xD2D9,0xCE46,0xC9C5,0xC55A,0xC104,0xBCC7,0xB8A2,0xB499,0xB0AD,0xACDE,0xA92F,0xA5A1,0xA236,0x9EED,0x9BCA,0x98CD,0x95F6,0x9348,0x90C3,0x8E69,0x8C39,0x8A35,0x885E,0x86B5,0x8539,0x83EC,0x82CD,0x81DF,0x8120,0x8091,0x8032,0x8004,0x8007,0x803A,0x809D,0x8131,0x81F5,0x82E8,0x840B,0x855D,0x86DE,0x888C,0x8A68,0x8C70,0x8EA4,0x9103,0x938C,0x963F,0x9919,0x9C1A,0x9F42,0xA28D,0xA5FD,0xA98E,0xAD40,0xB112,0xB501,0xB90D,0xBD34,0xC174,0xC5CC,0xCA3A,0xCEBC,0xD351,0xD7F7,0xDCAC,0xE16F,0xE63D,0xEB15,0xEFF5,0xF4DA,0xF9C5,
};




/*
 *  main() - Main code routine, initializes BSL and generates tone
 */

void main()
{
    DSK6713_AIC23_CodecHandle hCodec;
    Int16 loop_idx, sample;
	Uint8 DIP_flag;


    /* Initialize the board support library, must be called first */
    DSK6713_init();

	// Initialize LED and DIP switches
	DSK6713_LED_init();
	DSK6713_DIP_init();

    /* Start the codec */
    hCodec = DSK6713_AIC23_openCodec(0, &config);



    /* Generate a 1KHz sine wave for 5 seconds */

	while (1)
	{
		if 	(DSK6713_DIP_get(0) == 0)
			DIP_flag = 0;
		else if (DSK6713_DIP_get(1) == 0)
			DIP_flag = 1;
		else if (DSK6713_DIP_get(2) == 0)
			DIP_flag = 2;
		else if (DSK6713_DIP_get(3) == 0)
			DIP_flag = 3;
		else
			DIP_flag = 5;
		
		switch (DIP_flag)
		{
			case 0:
				DSK6713_LED_on(0);
				for (loop_idx = 0; loop_idx < DURATION*FREQ_0; loop_idx++)
			    {
			        for (sample = 0; sample < SINE_TABLE_SIZE_0; sample++)
			        {
			            /* Send a sample to the left channel */
			            while (!DSK6713_AIC23_write(hCodec, sinetable_0[sample]));

			            /* Send a sample to the right channel */
			            while (!DSK6713_AIC23_write(hCodec, sinetable_0[sample]));
			        }
	    		}
				
				DSK6713_LED_off(0);
			
			break;
			case 1:
				DSK6713_LED_on(1);
				
				for (loop_idx = 0; loop_idx < DURATION*FREQ_1; loop_idx++)
			    {
			        for (sample = 0; sample < SINE_TABLE_SIZE_1; sample++)
			        {
			            /* Send a sample to the left channel */
			            while (!DSK6713_AIC23_write(hCodec, sinetable_1[sample]));

			            /* Send a sample to the right channel */
			            while (!DSK6713_AIC23_write(hCodec, sinetable_1[sample]));
			        }
	    		}
				
				DSK6713_LED_off(1);
				
			break;
			case 2:
				/* 1KHz */
				DSK6713_LED_on(2);
								
				DSK6713_LED_off(2);
			
			break;
			case 3:
				/* 100 Hz */
				DSK6713_LED_on(3);
							
				DSK6713_LED_off(3);
				
			break;
			default:
				printf("default\n");
				
			break;
		}

	}

	
    /* Close the codec */
/*    DSK6713_AIC23_closeCodec(hCodec);*/
}
